function division(a, b) {
  return a / b;
}
